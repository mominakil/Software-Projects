﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PolyGames.Models;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.IO;

namespace PolyGames.DataAccessObjects
{
    public class GameDAO
    {
        //Use this connection string to connect to local desktop database
        string conString = "Data Source=localhost;Initial Catalog=PolyGames;Integrated Security=True";

        //Use this connection string to connect to the dev server (VDI) database
        //string conString = "Data Source=BISIISDEV;Initial Catalog=PolyGames;User ID=bisstudent;Password=bobby2013;Integrated Security=False";

        //Use this connection string to connect to the test server (VDI) database
        //string conString = "Data Source=BISIISTEST;Initial Catalog=PolyGames;User ID=bisstudent;Password=bobby2013;Integrated Security=False";

        //Query used for allYears page
        public Games getAllYears()
        {
            //Create connection to the backend database
            SqlConnection con = new SqlConnection(conString);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;

            //Set your SQL command
            cmd.CommandText = "SELECT DISTINCT Year FROM Games";

            //Create list that will hold the list of years returned
            List<Game> gs = new List<Game>();

            //Open connection to database
            con.Open();

            //Execute query
            SqlDataReader reader = cmd.ExecuteReader();

            //Read through the results of the query
            while (reader.Read())
            {
                Game game = new Game(Convert.ToInt32(reader["Year"]));
                gs.Add(game);
            }
            //Close database connection
            con.Close();

            //Adding the years to a list and returning it to the Home Controller
            Games allYears = new Games();
            allYears.Items = gs;
            return allYears;
        }

        public User Login(User UTC)
        {
            SqlConnection con = new SqlConnection(conString);
            string bruh = UTC.Email;
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = "SELECT Email, Password FROM UserLogin WHERE Password=@Password AND Email=@Email";
            cmd.Parameters.AddWithValue("@Email", UTC.Email);
            cmd.Parameters.AddWithValue("@Password", UTC.Password);

            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            User nu = new User(reader["Email"].ToString(),
                                reader["Password"].ToString());
            con.Close();
            return nu;
            
        }

        public void addUser(User u)
        {

            SqlConnection con = new SqlConnection(conString);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;

            con.Open();
            cmd.CommandText = "INSERT INTO UserLogin(Email, Password) VALUES(@Email, @Password)";
            if (u.Email == null)
            {
                cmd.Parameters.AddWithValue("@Email", DBNull.Value);
            }
            else
            {
                cmd.Parameters.AddWithValue("@Email", u.Email);
            }
            if (u.Password == null)
            {
                cmd.Parameters.AddWithValue("@Password", DBNull.Value);
            }
            else
            {
                cmd.Parameters.AddWithValue("@Password", u.Password);
            }
            cmd.ExecuteNonQuery();
            con.Close();
        }


        //Query to be used for Home page to display recently added games (video with clickable link that takes user to that game's game page)
        public Games getGamesOrderedByMostRecentlyAdded()
        {
            SqlConnection con = new SqlConnection(conString);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            List<Game> gs = new List<Game>();
            con.Open();

            using (con)
            {
                //Set your SQL command to use the stored procedure in the database
                cmd = new SqlCommand("usp_GetAllGamesOrderedByRecentlyAdded", con);
                //Set the type of command to a stored procedure
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Game g = new Game(
                                    Convert.ToInt32(reader["GameId"]),
                                    reader["GameName"].ToString(),
                                    reader["GameDescription"].ToString()
                                    //reader["pictureFilePath"].ToString(),
                                    //reader["videoFilePath"].ToString()
                               );

                    g.GamePictures = getGamePictures(g.Id);
                    g.GameVideos = getGameVideos(g.Id);

                    gs.Add(g);
                }
            }
            con.Close();

            //Adding the games to a list and returning them to the Home Controller
            Games allGames = new Games();
            allGames.Items = gs;
            return allGames;
            
        }

        //Query to be used for individual game page
        public Game getGameById(int id)
        {
            //Get game details, group details, video, and executable file (all 1:1 relationships)
            SqlConnection con = new SqlConnection(conString);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.Open();
            cmd = new SqlCommand("usp_GetGameDetailsOne", con);
            cmd.Parameters.AddWithValue("@GameId", id);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();

            Game g = new Game(
                                Convert.ToInt32(reader["GameId"]),
                                reader["GameName"].ToString(),                
                                reader["GameDescription"].ToString()   
                                );
                g.GameVideos = getGameVideos(g.Id);
                g.executableId = Convert.ToInt32(reader["executableId"]);
                g.GameName = reader["GroupName"].ToString();
                g.GroupId = Convert.ToInt32(reader["GroupId"]);
                g.Year = Convert.ToInt32(reader["Year"]);
                g.executableFilePath = reader["executableFilePath"].ToString();
         




            con.Close();

            //Get group member details (1:many relationship, one game can have many group members)
            g.groupMembers = getGroupMembers(g.GroupId);

            //Get picture details (1:many relationship, one game can have many pictures)
            g.GamePictures = getGamePictures(id);

            return g;
        }

        //Gets a list of group member details - called in the getGameById method
        public List<Student> getGroupMembers(int id)
        {
            List<Student> ss = new List<Student>();
            SqlConnection con = new SqlConnection(conString);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.Open();
            cmd = new SqlCommand("SELECT gm.MemberId, studentRole, studentName FROM GroupMembers gm inner join MembertoGroup mg on mg.MemberId = gm.MemberId WHERE mg.GroupId = @Id", con);
            cmd.Parameters.AddWithValue("@Id", id);

            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Student s = new Student(
                                Convert.ToInt32(reader["MemberId"]),
                                id,
                                reader["studentName"].ToString(),
                                reader["studentRole"].ToString()
                    );
                ss.Add(s);
            }
            con.Close();
            
            return ss;
        }

        //Query to be used for Game page to display all game pictures (called in the getGameByID method)
        public List<PictureFiles> getGamePictures(int id)
        {
            List<PictureFiles> ps = new List<PictureFiles>();
            SqlConnection con = new SqlConnection(conString);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.Open();
            cmd = new SqlCommand("SELECT pictureID, pictureFileName, pictureFilePath FROM PictureFiles WHERE gameID=@Id", con);
            //Add the game id value as a parameter in the query
            cmd.Parameters.AddWithValue("@Id", id);

            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                PictureFiles p = new PictureFiles(
                                Convert.ToInt32(reader["pictureID"]),
                                reader["pictureFileName"].ToString(),
                                reader["pictureFilePath"].ToString(),
                                id
                    );
                ps.Add(p);
            }
            con.Close();

            return ps;
        }

        public List<VideoFiles> getGameVideos(int id)
        {
            List<VideoFiles> vs = new List<VideoFiles>();
            SqlConnection con = new SqlConnection(conString);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.Open();
            cmd = new SqlCommand("SELECT videoID, videoFileName, videoFilePath FROM videoFiles WHERE gameID=@Id", con);
            //Add the game id value as a parameter in the query
            cmd.Parameters.AddWithValue("@Id", id);

            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                VideoFiles v = new VideoFiles(
                                Convert.ToInt32(reader["videoID"]),
                                reader["videoFileName"].ToString(),
                                reader["videoFilePath"].ToString(),
                                id
                    );
                vs.Add(v);
            }
            con.Close();

            return vs;
        }

        //SQL commands to be used for the AddGame page
        public void addGame(Game g)
        {
            
            SqlConnection con = new SqlConnection(conString);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;

            //Insert values into Games table
            con.Open();
            cmd.CommandText = "INSERT INTO Games(Year, GameName, GameDescription) VALUES(@Year, @GameName, @GameDescription)";
            if (g.GameName == null) // need to add a way to implement a group id increment 
            {
                cmd.Parameters.AddWithValue("@GameName", DBNull.Value);
            }
            else
            {
                cmd.Parameters.AddWithValue("@GameName", g.GameName);
            }
            if (g.Description == null)
            {
                cmd.Parameters.AddWithValue("@GameDescription", DBNull.Value);
            }
            else
            {
                cmd.Parameters.AddWithValue("@GameDescription", g.Description);
            }
            cmd.Parameters.AddWithValue("@Year", g.Year);
            cmd.ExecuteNonQuery();
            con.Close();

            //Lookup the GameId and GroupId based on the GameName and GameDescription to use in the rest of the inserts
            con.Open();
            cmd.CommandText = "SELECT GameId, GroupId FROM Games WHERE GameName=@gName AND GameDescription=@gDesc";
            cmd.Parameters.AddWithValue("@gName", g.GameName);
            cmd.Parameters.AddWithValue("@gDesc", g.Description);
            SqlDataReader readerTwo = cmd.ExecuteReader();
            readerTwo.Read();
            int currentGameId = (Convert.ToInt32(readerTwo["GameId"]));
            int gameGroupId = (Convert.ToInt32(readerTwo["GroupId"]));
            con.Close();

            //Insert values into Group table
            con.Open();
            cmd.CommandText = "INSERT INTO PolyGamesGroups (GroupId, GroupName) VALUES (@grpId, @GroupName)";
            if (g.GroupName == null)
            {
                cmd.Parameters.AddWithValue("@GroupName", DBNull.Value);
            }
            else
            {
                cmd.Parameters.AddWithValue("@GroupName", g.GroupName);
            }
            cmd.Parameters.AddWithValue("@grpId", gameGroupId);
            cmd.ExecuteNonQuery();
            con.Close();

            //Insert values into Group Members table
            cmd.CommandText = "INSERT INTO GroupMembers (GroupId, studentRole, studentName) VALUES (@gId, @StudentRole, @StudentName)";
            cmd.Parameters.AddWithValue("@gId", gameGroupId);
            if (g.studentNameOne == null)
            {
                cmd.Parameters.AddWithValue("@StudentName", DBNull.Value);
            }
            else
            {
                cmd.Parameters.AddWithValue("@StudentName", g.studentNameOne);
            }
            if (g.studentRoleOne == null)
            {
                cmd.Parameters.AddWithValue("@StudentRole", DBNull.Value);
            }
            else
            {
                cmd.Parameters.AddWithValue("@StudentRole", g.studentRoleOne);
            }
            con.Open();
            cmd.ExecuteNonQuery();

            //Had to create individual group members so that each member had it's own text box and unique values to store in the database
            //Check if Group Member Two fields were filled out, execute query to add them to the DB if they were
            if (g.studentNameTwo != null && g.studentRoleTwo != null)
            {
                cmd.CommandText = "INSERT INTO GroupMembers (GroupId, studentRole, studentName) VALUES (@gTwoId, @StudentRoleTwo, @StudentNameTwo)";
                cmd.Parameters.AddWithValue("@gTwoId", gameGroupId);
                cmd.Parameters.AddWithValue("@StudentRoleTwo", g.studentRoleTwo);
                cmd.Parameters.AddWithValue("@StudentNameTwo", g.studentNameTwo);
                cmd.ExecuteNonQuery();
            }

            //Check if Group Member Three fields were filled out, execute query to add them to the DB if they were
            if (g.studentNameThree != null && g.studentRoleThree != null)
            {
                cmd.CommandText = "INSERT INTO GroupMembers (GroupId, studentRole, studentName) VALUES (@gThreeId, @StudentRoleThree, @StudentNameThree)";
                cmd.Parameters.AddWithValue("@gThreeId", gameGroupId);
                cmd.Parameters.AddWithValue("@StudentRoleThree", g.studentRoleThree);
                cmd.Parameters.AddWithValue("@StudentNameThree", g.studentNameThree);
                cmd.ExecuteNonQuery();
            }

            //Check if Group Member Four fields were filled out, execute query to add them to the DB if they were
            if (g.studentNameFour != null && g.studentRoleFour != null)
            {
                cmd.CommandText = "INSERT INTO GroupMembers (GroupId, studentRole, studentName) VALUES (@gFourId, @StudentRoleFour, @StudentNameFour)";
                cmd.Parameters.AddWithValue("@gFourId", gameGroupId);
                cmd.Parameters.AddWithValue("@StudentRoleFour", g.studentRoleFour);
                cmd.Parameters.AddWithValue("@StudentNameFour", g.studentNameFour);
                cmd.ExecuteNonQuery();
            }

            //Check if Group Member Five fields were filled out, execute query to add them to the DB if they were
            if (g.studentNameFive != null && g.studentRoleFive != null)
            {
                cmd.CommandText = "INSERT INTO GroupMembers (GroupId, studentRole, studentName) VALUES (@gFiveId, @StudentRoleFive, @StudentNameFive)";
                cmd.Parameters.AddWithValue("@gFiveId", gameGroupId);
                cmd.Parameters.AddWithValue("@StudentRoleFive", g.studentRoleFive);
                cmd.Parameters.AddWithValue("@StudentNameFive", g.studentNameFive);
                cmd.ExecuteNonQuery();
            }

            //Check if Group Member Six fields were filled out, execute query to add them to the DB if they were
            if (g.studentNameSix != null && g.studentRoleSix != null)
            {
                cmd.CommandText = "INSERT INTO GroupMembers (GroupId, studentRole, studentName) VALUES (@gSixId, @StudentRoleSix, @StudentNameSix)";
                cmd.Parameters.AddWithValue("@gSixId", gameGroupId);
                cmd.Parameters.AddWithValue("@StudentRoleSix", g.studentRoleSix);
                cmd.Parameters.AddWithValue("@StudentNameSix", g.studentNameSix);
                cmd.ExecuteNonQuery();
            }
            con.Close();

            //Insert values into Pictures table
            con.Open();
            if (g.picturesUpload != null)
            {
                string pictureFileName;
                int pictureFileSize = 0;
                int fileSize = 0;
                int picCounter = 0;

                using (con)
                {
                    cmd = new SqlCommand("usp_AddNewPictureFile", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    //loop through the object that holds all of the pictures the user uploaded
                    foreach (var item in g.picturesUpload)
                    {
                        //Extract file attributes and save them to the database using the stored procedure
                        pictureFileName = item.FileName;
                        pictureFileSize = item.ContentLength;
                        fileSize = pictureFileSize / 1000;
                        cmd = new SqlCommand("usp_AddNewPictureFile", con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@pictureFileName", pictureFileName);
                        cmd.Parameters.AddWithValue("@pictureFileSize", fileSize);
                        cmd.Parameters.AddWithValue("@pictureFilePath", "~/PictureFileUpload/" + pictureFileName);
                        cmd.Parameters.AddWithValue("@gameID", currentGameId);
                        cmd.ExecuteNonQuery();
                        
                        picCounter++;
                        if (picCounter == 5) break; //once we've added 5 pictures to the DB, stop
                    }
                }
            }
            con.Close();

            //Insert values into Video table
            string CS = conString;
            SqlConnection conTwo = new SqlConnection(CS);
            SqlCommand cmdTwo = new SqlCommand();
            cmdTwo.Connection = conTwo;
            conTwo.Open();
            if (g.videoUpload != null)
            {
                string videoFileName = Path.GetFileName(g.videoUpload.FileName);
                int videoFileSize = g.videoUpload.ContentLength;
                int fileSize = videoFileSize / 1000;

                using (conTwo)
                {
                    cmdTwo = new SqlCommand("usp_AddNewVideoFile", conTwo);
                    cmdTwo.CommandType = CommandType.StoredProcedure;
                    cmdTwo.Parameters.AddWithValue("@videoFileName", videoFileName);
                    cmdTwo.Parameters.AddWithValue("@videoFileSize", fileSize);
                    cmdTwo.Parameters.AddWithValue("@videoFilePath", "~/VideoFileUpload/" + videoFileName);
                    cmdTwo.Parameters.AddWithValue("@gameID", currentGameId);
                    cmdTwo.ExecuteNonQuery();
                }
                conTwo.Close();
            }


            //Insert values into Executable table
            SqlConnection conThree = new SqlConnection(CS);
            SqlCommand cmdThree = new SqlCommand();
            cmdThree.Connection = conThree;
            conThree.Open();
            if (g.executableUpload != null)
            {
                string executableFileName = Path.GetFileName(g.executableUpload.FileName);
                int executableFileSize = g.executableUpload.ContentLength;
                int fileSize = executableFileSize / 1000;

                using (conThree)
                {
                    cmdThree = new SqlCommand("usp_AddNewExecutableFile", conThree);
                    cmdThree.CommandType = CommandType.StoredProcedure;
                    cmdThree.Parameters.AddWithValue("@executableFileName", executableFileName);
                    cmdThree.Parameters.AddWithValue("@executableFileSize", fileSize);
                    cmdThree.Parameters.AddWithValue("@executableFilePath", "~/ExecutableFileUpload/" + executableFileName);
                    cmdThree.Parameters.AddWithValue("@gameID", currentGameId);
                    cmdThree.ExecuteNonQuery();
                }
                conThree.Close();
            }
            
        }

        //Query to be used for Games by Year page
        public  Games getGamesByYear(int year)
        {
            SqlConnection con = new SqlConnection(conString);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            List<Game> gs = new List<Game>();
            con.Open();

            using (con)
            {
                cmd = new SqlCommand("usp_GetAllGamesByYear", con);
                cmd.Parameters.AddWithValue("@GameYear", year);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Game g = new Game(
                                    Convert.ToInt32(reader["GameId"]),
                                    reader["GameName"].ToString(),
                                    reader["GameDescription"].ToString(),
                                    reader["pictureFilePath"].ToString(),
                                    year
                               );
                    gs.Add(g);
                }
            }
            Games allGames = new Games(); 
            allGames.Items = gs;
            con.Close();
            return allGames;
        }

        //Query to be used for All Games page
        public Games getAllGames() 
        {
            SqlConnection con = new SqlConnection(conString);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            List<Game> gs = new List<Game>();
            con.Open();

            using (con)
            {
                cmd = new SqlCommand("usp_GetAllGames", con);
                cmd.CommandType = CommandType.StoredProcedure;
                //cmd.CommandText = "SELECT Games.GameId, GameName, GameDescription, pictureFilePath FROM Games INNER JOIN PictureFiles ON Games.GameId = PictureFiles.gameID";
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Game g = new Game(
                                    Convert.ToInt32(reader["GameId"]),
                                    reader["GameName"].ToString(),
                                    reader["GameDescription"].ToString(),
                                    reader["pictureFilePath"].ToString()
                               );
                    gs.Add(g);
                }
            }
            Games allGames = new Games(); 
            allGames.Items = gs;
            con.Close();
            return allGames;
        }

        //Command to delete all game data for one game
        public void deleteGame(int id, int groupId)
        {
            SqlConnection con = new SqlConnection(conString);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd = new SqlCommand("usp_DeleteGame", con);
            cmd.Parameters.AddWithValue("@GameId", id);
            cmd.Parameters.AddWithValue("@GroupId", groupId);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            return;
        }

        //SQL Commands to update game details
        public Game updateGame(Game g)
        {
            SqlConnection con = new SqlConnection(conString);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.Open();

            //update game table values
            cmd.CommandText = "UPDATE Games SET GameName=@GameName, Year=@Year, GameDescription=@GameDescription WHERE GameId=@GameId";
            cmd.Parameters.AddWithValue("@GameId", g.Id);
            cmd.Parameters.AddWithValue("@GameName", g.GameName);
            cmd.Parameters.AddWithValue("@Year", g.Year);
            cmd.Parameters.AddWithValue("@GameDescription", g.Description);
            cmd.ExecuteNonQuery();

            //update group name
            cmd.CommandText = "UPDATE PolyGamesGroups SET GroupName=@GroupName WHERE GroupId=@GroupId";
            cmd.Parameters.AddWithValue("@GroupId", g.GroupId);
            cmd.Parameters.AddWithValue("@GroupName", g.GroupName);
            cmd.ExecuteNonQuery();

            //update group member one
            cmd.CommandText = "UPDATE GroupMembers SET studentRole=@StudentRoleOne, studentName=@StudentNameOne WHERE MemberId=@oneId";
            cmd.Parameters.AddWithValue("@oneId", g.groupMembers[0].memberId);
            cmd.Parameters.AddWithValue("@StudentRoleOne", g.groupMembers[0].studentRole);
            cmd.Parameters.AddWithValue("@StudentNameOne", g.groupMembers[0].studentName);
            cmd.ExecuteNonQuery();

            //if there is a second group member, update group member two info
            if (g.groupMembers.Count >= 2)
            {
                cmd.CommandText = "UPDATE GroupMembers SET studentRole=@StudentRoleTwo, studentName=@StudentNameTwo WHERE MemberId=@twoId";
                cmd.Parameters.AddWithValue("@twoId", g.groupMembers[1].memberId);
                cmd.Parameters.AddWithValue("@StudentRoleTwo", g.groupMembers[1].studentRole);
                cmd.Parameters.AddWithValue("@StudentNameTwo", g.groupMembers[1].studentName);
                cmd.ExecuteNonQuery();
            }

            //if there is a third group member, update group member three info
            if (g.groupMembers.Count >= 3)
            {
                cmd.CommandText = "UPDATE GroupMembers SET studentRole=@StudentRoleThree, studentName=@StudentNameThree WHERE MemberId=@threeId";
                cmd.Parameters.AddWithValue("@threeId", g.groupMembers[2].memberId);
                cmd.Parameters.AddWithValue("@StudentRoleThree", g.groupMembers[2].studentRole);
                cmd.Parameters.AddWithValue("@StudentNameThree", g.groupMembers[2].studentName);
                cmd.ExecuteNonQuery();
            }

            //if there is a fourth group member, update group member four info
            if (g.groupMembers.Count >= 4)
            {
                cmd.CommandText = "UPDATE GroupMembers SET studentRole=@StudentRoleFour, studentName=@StudentNameFour WHERE MemberId=@fourId";
                cmd.Parameters.AddWithValue("@fourId", g.groupMembers[3].memberId);
                cmd.Parameters.AddWithValue("@StudentRoleFour", g.groupMembers[3].studentRole);
                cmd.Parameters.AddWithValue("@StudentNameFour", g.groupMembers[3].studentName);
                cmd.ExecuteNonQuery();
            }

            //if there is a fifth group member, update group member five info
            if (g.groupMembers.Count >= 5)
            {
                cmd.CommandText = "UPDATE GroupMembers SET studentRole=@StudentRoleFive, studentName=@StudentNameFive WHERE MemberId=@fiveId";
                cmd.Parameters.AddWithValue("@fiveId", g.groupMembers[4].memberId);
                cmd.Parameters.AddWithValue("@StudentRoleFive", g.groupMembers[4].studentRole);
                cmd.Parameters.AddWithValue("@StudentNameFive", g.groupMembers[4].studentName);
                cmd.ExecuteNonQuery();
            }

            //if there is a sixth group member, update group member six info
            if (g.groupMembers.Count >= 6)
            {
                cmd.CommandText = "UPDATE GroupMembers SET studentRole=@StudentRoleSix, studentName=@StudentNameSix WHERE MemberId=@sixId";
                cmd.Parameters.AddWithValue("@sixId", g.groupMembers[5].memberId);
                cmd.Parameters.AddWithValue("@StudentRoleSix", g.groupMembers[5].studentRole);
                cmd.Parameters.AddWithValue("@StudentNameSix", g.groupMembers[5].studentName);
                cmd.ExecuteNonQuery();
            }

            //update executable file
            if (g.executableUpload != null) //IF a new executable file was uploaded
            {
                //extract the file name and size from the upload
                string executableFileName = Path.GetFileName(g.executableUpload.FileName);
                int executableFileSize = g.executableUpload.ContentLength;
                int fileSize = executableFileSize / 1000;

                cmd.CommandText = "UPDATE ExecutableFiles SET executableFileName=@executableFileName, executableFileSize=@executableFileSize, " + 
                    "executableFilePath=@executableFilePath WHERE gameID=@GameId";
                cmd.Parameters.AddWithValue("@executableFileName", executableFileName);
                cmd.Parameters.AddWithValue("@executableFileSize", fileSize);
                cmd.Parameters.AddWithValue("@executableFilePath", "~/ExecutableFileUpload/" + executableFileName);
               // cmd.Parameters.AddWithValue("@GmId", g.Id);
                cmd.ExecuteNonQuery();
            }

            //update video file
            if (g.videoUpload != null) //IF a new video file was uploaded
            {
                //extract the file name and size from the upload
                string videoFileName = Path.GetFileName(g.videoUpload.FileName);
                int videoFileSize = g.videoUpload.ContentLength;
                int fileSize = videoFileSize / 1000;

                cmd.CommandText = "UPDATE VideoFiles SET videoFileName=@videoFileName, videoFileSize=@videoFileSize, " +
                    "videoFilePath=@videoFilePath WHERE gameID=@GameId";
                cmd.Parameters.AddWithValue("@videoFileName", videoFileName);
                cmd.Parameters.AddWithValue("@videoFileSize", fileSize);
                cmd.Parameters.AddWithValue("@videoFilePath", "~/VideoFileUpload/" + videoFileName);
                cmd.ExecuteNonQuery();

            }

            //update pictures - deletes the old ones and replaces them with the new pictures the user selected
            if (g.picturesUpload.Any())
            {
                //extract the file name and size from the upload
                string pictureFileName;
                int pictureFileSize = 0;
                int fileSize = 0;
                int picCounter = 0;

                foreach (var item in g.picturesUpload)
                {
                    if (item != null)
                    {
                        //delete existing pictures for this game
                        cmd.CommandText = "DELETE FROM PictureFiles where gameID=@GameId";
                        cmd.ExecuteNonQuery();
                        break;
                    }
                    break;
                }
                
                //loop through each new picture that user uploaded
                foreach (var item in g.picturesUpload)
                {
                    if (item != null)
                    {
                        pictureFileName = item.FileName;
                        pictureFileSize = item.ContentLength;
                        fileSize = pictureFileSize / 1000;
                        cmd = new SqlCommand("usp_AddNewPictureFile", con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@pictureFileName", pictureFileName);
                        cmd.Parameters.AddWithValue("@pictureFileSize", fileSize);
                        cmd.Parameters.AddWithValue("@pictureFilePath", "~/PictureFileUpload/" + pictureFileName);
                        cmd.Parameters.AddWithValue("@gameID", g.Id);
                        cmd.ExecuteNonQuery();
                        picCounter++;
                        if (picCounter == 5) break; //once we've added 5 pictures to the DB, stop
                    }
                }  
            }

            con.Close();

            return g;
        }


    }
}