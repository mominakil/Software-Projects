﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PolyGames.Models
{
    public class User
    {
        public string Email { set; get; }
        public string Password { set; get; }

        public User(string em, string pw)
        {
            Email = em;
            Password = pw;
        }

        public User() { }
    }
}