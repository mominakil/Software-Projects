﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PolyGames.Models;
using PolyGames.DataAccessObjects;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Diagnostics;


namespace PolyGames.Controllers
{
    //Controls all of the websites actions
    public class HomeController : Controller
    {
        //Home page
        public ActionResult Index()
        {
            //Create Database Access Object in order to access the SQL query
            GameDAO dAO = new GameDAO();
            Games g = dAO.getGamesOrderedByMostRecentlyAdded();

            //Returns the list of games to the Index/Home Page view (Index.cshtml)
            return View(g);
        }

        public ActionResult AddGame(Game g, string Save)
        {

            //If user is logged in
            if (Session["Email"] != null)
            {
                //Save is the name of the Value on the Add a Game page Button
                if (Save == "Save")
                {
                    //check for uploaded pictures and save them to the appropriate folder
                    if (g.picturesUpload != null)
                    {
                        string pictureFileName;
                        int picCounter = 0;
                        
                        //loop through the object that holds all of the pictures the user uploaded
                        foreach (var item in g.picturesUpload)
                        {
                            //Extract file name and save the picture to the PictureFileUploaded folder in the website Home directory
                            pictureFileName = item.FileName;
                            item.SaveAs(Server.MapPath("~/PictureFileUpload/" + pictureFileName));
                            picCounter++;
                            //Only want to allow 5 pictures max to be saved to the DB so stop adding pictures once you hit 5, even if user selected more
                            if (picCounter == 5) break;
                        }
                    }

                    //check for uploaded video and save it to the appropriate folder
                    if(g.videoUpload != null)
                    {
                        //Extract file name and save the video to the VideoFileUploaded folder in the website Home directory
                        string videoFileName = Path.GetFileName(g.videoUpload.FileName);
                        g.videoUpload.SaveAs(Server.MapPath("~/VideoFileUpload/" + videoFileName));
                    }

                    //check for uploaded executable file and save it to the appropriate folder
                    if (g.executableUpload != null)
                    {
                        //Extract file name and save the executable to the ExecutableFileUploaded folder in the website Home directory
                        string executableFileName = Path.GetFileName(g.executableUpload.FileName);
                        g.executableUpload.SaveAs(Server.MapPath("~/ExecutableFileUpload/" + executableFileName));
                    }

                    //Create Database Access Object in order to access the addGame method which adds the game to the database
                    GameDAO dAO = new GameDAO();
                    dAO.addGame(g);
                    ViewBag.Message = "  Game Uploaded Successfully!";
                }
            }
            //If user is not logged in, redirect them to the login page
            else
            {
                return RedirectToAction("Login");
            }

            //Clear the form fields after form has been submitted
            ModelState.Clear();

            return View("AddGame");
        }

        //Main Game page where you can view and edit game details
        public ActionResult Game(Game gm, string Save)
        {

            GameDAO dAO = new GameDAO();

            //this means the user is saving edits to the game
            if (Save == "Save")
            {
                //check if they uploaded a new executable file. If they did then save it to the appropriate folder
                if (gm.executableUpload != null)
                {
                    string executableFileName = Path.GetFileName(gm.executableUpload.FileName);
                    gm.executableUpload.SaveAs(Server.MapPath("~/ExecutableFileUpload/" + executableFileName));
                }

                //check if they uploaded a new video file. If they did then save it to the appropriate folder
                if (gm.videoUpload != null)
                {
                    string videoFileName = Path.GetFileName(gm.videoUpload.FileName);
                    gm.videoUpload.SaveAs(Server.MapPath("~/VideoFileUpload/" + videoFileName));
                }

                //check if they uploaded any new pictures. If they did then save them to the appropriate folder
                if (gm.picturesUpload.Any())
                {
                    string pictureFileName;
                    int picCounter = 0;

                    foreach (var item in gm.picturesUpload)
                    {
                        if (item != null)
                        {
                            pictureFileName = item.FileName;
                            item.SaveAs(Server.MapPath("~/PictureFileUpload/" + pictureFileName));
                            picCounter++;
                            if (picCounter == 5) break;
                        }
                    }
                }

                //call the updateGame method in the GameDAO which saves the edited game details to the database
                dAO.updateGame(gm);
            }

            //get the updated game values that you just saved to the database so that you can re-display them
            Game g = dAO.getGameById(gm.Id);

            //set is editable to false so that the Game page shows the correct view
            g.IsEditable = false;

            //re-display the updated game values
            return View(g);
        }

        //AllGames.cshtml page action
        public ActionResult AllGames()
        {
            //Create Database Access Object in order to access the SQL query that returns a list of all the games
            GameDAO dao = new GameDAO();
            Games g = dao.getAllGames();

            //Returns the list of games to the AllGames page
            return View(g);
        }

        //GamesByYear.cshtml page action
        public ActionResult GamesByYear(int year)
        {
            //Create Database Access Object in order to access the SQL query that returns a list of all the games in a certain year
            GameDAO dao = new GameDAO();
            Games g = dao.getGamesByYear(year);

            //Returns the list of games to the GamesByYear page
            return View(g);
        }

        //Game.cshtml page - action when user clicks the delete link
        public ActionResult GameDelete(int id, int groupId)
        {
            //If user is logged in
            if (Session["Email"] != null)
            {
                GameDAO dAO = new GameDAO();
                dAO.deleteGame(id, groupId);

                //Since you've just deleted the game for the page you're on, you are redirected to the Home/Index page
                Games g = dAO.getGamesOrderedByMostRecentlyAdded();
                return View("Index", g);
            }
            else
            {
                //If you're not logged in, you're taken to the login page
                return RedirectToAction("Login");
            }
        }

        //Game.cshtml page - action when user clicks the edit link
        public ActionResult GameEdit(int id)
        {
            if (Session["Email"] != null)
            {
                //Getting the game details
                GameDAO dAO = new GameDAO();
                Game g = dAO.getGameById(id);

                //Setting the game attribute to editable so that the editable view is shown on the Game.cshtml
                g.IsEditable = true;

                //Returning to the Game.cshtml page passing the original game details but as the editable view
                return View("Game", g);
            }
            else
            {
                return RedirectToAction("Login");
            }
        }

        //Game.cshtml page - action when user clicks the download link
        public ActionResult DownloadGame(string path)
        {
            //Saves the executable file to the users Download directory
            return File(path, "application", Path.GetFileName(path));
        }

        public ActionResult Login(User u, string Save, String PLI)
        {
            if (Save == "Save")
            {
                if (u.Email != null || u.Password != null && u.Email.Contains("SaskPolytech.ca"))
                {
                    Session["Email"] = u.Email;
                    Session["Email"] = u.Password;
                    GameDAO dao = new GameDAO();
                    dao.Login(u);
                    ViewBag.Message = "Logged In";
                    return View();
                }
                else
                {
                    ViewBag.Message = "Invalid Email or Password";
                    return View();
                }
            }
            if (PLI == "PLI")
            {
                ViewBag.Message("Please log in to add a game");
            }

            return View("Login");

        }

        //allYears.cshtml action
        public ActionResult allYears()
        {
            //Gets and returns a list of distinct years
            GameDAO dao = new GameDAO();
            Games y = dao.getAllYears();
            return View(y);
        }

    }
}